package pk.quranpk

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.text.InputType
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private val green = Color.rgb(7,92,60)

    override fun onCreate(b: Bundle?) { super.onCreate(b); showSurahs() }

    private fun base(title:String): LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL
        val head=LinearLayout(this); head.orientation=LinearLayout.VERTICAL; head.setPadding(24,24,24,20)
        head.setBackgroundColor(green)
        val t=TextView(this); t.text=title; t.textSize=28f; t.setTextColor(Color.WHITE)
        head.addView(t)
        val s=EditText(this); s.hint="قرآن میں عربی لفظ تلاش کریں"; s.setSingleLine(); s.setTextColor(Color.WHITE); s.setHintTextColor(Color.LTGRAY)
        s.inputType=InputType.TYPE_CLASS_TEXT; head.addView(s)
        s.setOnEditorActionListener { _,_,_-> search(s.text.toString()); true }
        root.addView(head)
        box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(16,16,16,80)
        val scroll=ScrollView(this); scroll.addView(box); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    private fun showSurahs(){
        val root=base("☪ Quran PK\nصرف قرآن پاک")
        box.addView(TextView(this).apply{ text="سورتیں"; textSize=22f; setPadding(8,8,8,16)})
        load("https://api.alquran.cloud/v1/surah"){ j->
            val a=j.getJSONArray("data")
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                val v=TextView(this); v.text="${o.getInt("number")}.  ${o.getString("name")}    •    ${o.getInt("numberOfAyahs")} آیات"
                v.textSize=19f; v.setTextColor(green); v.setPadding(18,22,18,22)
                v.setOnClickListener{ openSurah(o.getInt("number"))}; box.addView(v)
            }
        }
        setContentView(root)
    }

    private fun openSurah(n:Int){
        val root=base("قرآن پاک")
        val back=Button(this); back.text="← سورتوں پر واپس"; back.setOnClickListener{showSurahs()}; box.addView(back)
        load("https://api.alquran.cloud/v1/surah/$n/quran-uthmani"){j->
            val s=j.getJSONObject("data"); val title=TextView(this); title.text=s.getString("name"); title.textSize=24f; title.gravity=Gravity.CENTER; box.addView(title)
            val a=s.getJSONArray("ayahs")
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i); val c=TextView(this)
                c.text="آیت ${o.getInt("numberInSurah")} • پارہ ${o.getInt("juz")}\n\n${o.getString("text")}"
                c.textSize=24f; c.setPadding(12,20,12,20); c.setTextColor(Color.DKGRAY); box.addView(c)
            }
        }; setContentView(root)
    }

    private fun search(q:String){
        if(q.isBlank()) return
        val root=base("🔎 Search")
        load("https://api.alquran.cloud/v1/search/${java.net.URLEncoder.encode(q,"UTF-8")}/all/quran-uthmani"){j->
            val d=j.optJSONObject("data"); val m=d?.optJSONArray("matches")
            box.addView(TextView(this).apply{text=""$q" — ${m?.length() ?: 0} نتائج"; textSize=21f})
            if(m!=null) for(i in 0 until minOf(m.length(),100)){
                val o=m.getJSONObject(i); val s=o.getJSONObject("surah")
                box.addView(TextView(this).apply{
                    text="${s.getString("name")} • آیت ${o.getInt("numberInSurah")} • پارہ ${o.getInt("juz")}\n${o.getString("text")}"
                    textSize=21f; setPadding(10,18,10,18)
                })
            }
        }; setContentView(root)
    }

    private fun load(url:String, done:(JSONObject)->Unit){
        thread {
            try{
                val c=URL(url).openConnection() as HttpURLConnection; c.connectTimeout=15000; c.readTimeout=15000
                val txt=c.inputStream.bufferedReader().readText(); c.disconnect()
                val j=JSONObject(txt)
                runOnUiThread{done(j)}
            }catch(e:Exception){runOnUiThread{Toast.makeText(this,"انٹرنیٹ کنکشن چیک کریں",Toast.LENGTH_LONG).show()}}
        }
    }
}
