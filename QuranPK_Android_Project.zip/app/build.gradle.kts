plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "pk.quranpk"; compileSdk = 35
    defaultConfig { applicationId = "pk.quranpk"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
