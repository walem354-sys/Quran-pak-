Quran PK Android Project
------------------------
یہ ابتدائی Android project صرف قرآن پاک کے لیے ہے، ترجمہ شامل نہیں۔

اہم features:
- 114 سورتوں کی فہرست
- عربی قرآن
- عربی لفظ Search
- پارہ اور آیت نمبر

APK بنانے کے لیے:
1) Android Studio انسٹال کریں۔
2) اس project folder کو Android Studio میں Open کریں۔
3) Gradle sync مکمل ہونے دیں۔
4) Build > Build APK(s) کریں۔

نوٹ: موجودہ ورژن قرآن کا متن API سے internet کے ذریعے حاصل کرتا ہے۔ اگلے مرحلے میں offline Quran data، bookmark، dark mode اور audio شامل کیے جا سکتے ہیں۔
